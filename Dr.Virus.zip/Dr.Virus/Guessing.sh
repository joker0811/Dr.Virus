#!/bin/bash
#made in 30/1/2019
       echo                " Dr.Virus v 1.3"
       echo           "###############################"
       echo           "#                             #"
       echo           "#                             #"
       echo           "#           Dr.Virus          #"
       echo           "#                             #"
       echo           "#                             #"
       echo           "#                             #"
       echo           "###############################"
          echo               "Developed team:"
          echo                  "Dr.Virus"
sleep 1
echo "1-Facebook"
sleep 1
echo "2-instagram"
sleep 1
echo "3-twitter {Root}"
sleep 1
echo "4-Gemail"
sleep 1
echo "5-password list {aleardy}"
sleep 1
echo "6-exit"
sleep 1
echo "7-my office on facebook"
read -p "enter a number : " number
#--------------------------------
if [ $number -eq 1 ]
then
echo "### installing checkIP"
git clone https://github.com/rebaiAla/checkIP
pip2 install mechanize
ls
cd checkIP
ls
python2 FBIP.py
fi
#---------------------------
if [ $number -eq 2 ]
then
echo "### installing instabot"
git clone https://github.com/Senitopeng/instabot
ls
pip2 install mechanize
pip install instabot
pip2 install -r requestments
cd instabot
ls
chmod 755 instabot
bash instabot
fi
#----------------------------
if [ $number -eq 3 ]
then
echo "### installing tweetshell"
git clone https://github.com/thelinuxchoice/tweetshell
ls
pip2 install mechanize
cd tweetshell
chmod 755 install.sh tweetshell.sh
bash install.sh
bash tweetshell.sh
fi
#--------------------------------
if [ $number -eq 4 ]
then
echo "### installing Gemail-Hack "
git clone https://github.com/Ha3MrX/Gemail-Hack
ls
cd Gemail-Hack
ls
pip2 install mechanize
chmod 755 gemailhack.py
sleep 0.5
python2 gemailhack.py
fi
#-----------------------------------
if [ $number -eq 5 ]
then
echo "Ali.txt in Dr.Virus"
sleep 1
echo "done .."
fi
#-----------------------------------
if [ $number -eq 6 ]
then
echo "good byeeeee ."
fi
#------------------------------------
if [ $number -eq 7 ]
then
echo "https://www.facebook.com/hacker.hide.09"
sleep 383
else
echo "wrong !."
fi
